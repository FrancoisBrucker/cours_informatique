# connaître son numéro

## page générale

1. je rentre mon nom dans un champ texte : François puis j'appuie sur la touche entrée.
2. En dessous du champ texte, on affiche alors Bonjour François, votre numéro est le X

X est écrit en gros au milieu de la page.

## page du numéro

<http://localhost/prénom/XXXX>

doit rendre le numéro associé à XXXX