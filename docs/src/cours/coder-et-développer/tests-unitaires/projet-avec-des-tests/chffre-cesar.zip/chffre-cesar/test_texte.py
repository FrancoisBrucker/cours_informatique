from texte import conversion

def test_conversion():
    assert "ABC DE" == conversion("ÀBÇ dè")