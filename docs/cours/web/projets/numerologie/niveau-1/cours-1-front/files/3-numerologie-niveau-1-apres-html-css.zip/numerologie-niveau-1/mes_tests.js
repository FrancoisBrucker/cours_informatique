nom = "monde"

console.log("bonour " + nom + " !!")

console.log("꧁".charCodeAt(0))
console.log(("꧁".charCodeAt(0)).toString(16))
