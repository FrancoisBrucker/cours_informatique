nom = "monde"

console.log("bonour " + nom + " !!")
