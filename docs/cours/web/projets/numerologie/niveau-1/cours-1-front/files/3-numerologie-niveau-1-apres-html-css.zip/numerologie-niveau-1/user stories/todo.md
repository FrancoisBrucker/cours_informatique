# Todos


- [X] associer un chiffre à un nom
    - [X] ~~numéro unicode/utf8 d'un caractère~~
    - [X] ~~sommer des numéro des caractères d'une chaine de caractères~~
    - [X] ~~sommer les chiffre d'un nombre~~
    - [X] ~~sommer itérativement jusqu'à convergence (car $10x + y > x+y$ si $x > 0$)~~
- [X] ~~créer un champ texte dans un fichier html~~
- [X] ~~ajouter du style dans le html.~~
- [X] ~~inclure une bibliothèque css~~
- [ ] récupérer en html le contenu d'un champ texte lorsque l'on appuie sur la touche entrée
- [ ] modifier l'arbre DOM avec du texte.
- [ ] récupérer un info de l'url et la traiter